#include <iostream>
#include "fin_recipes.h"

using namespace std;

int main()
{
	vector<double> cflows;
	vector<double> times;

	cflows.push_back(-100.0);  times.push_back(0.0);
	cflows.push_back(75.0);    times.push_back(1.0);
	cflows.push_back(75.0);    times.push_back(2.0);

	double r = 0.10;

	cout << " present value, 10\% discretely compounded interest = ";
	cout << cash_flow_pv_discrete(times, cflows, r) << endl;

	return 0;
}

