#include <iostream>
#include "fin_recipes.h"

using namespace std;

int main()
{
	vector<double> cflows;
	vector<double> times;

	cflows.push_back(-100.0);  times.push_back(0.0);
	cflows.push_back(10.0);    times.push_back(1.0);
	cflows.push_back(110.0);   times.push_back(2.0);

	double r = 0.05;

	cout << " present value, 5\% discretely compounded interest = ";
	cout << cash_flow_pv_discrete(times, cflows, r) << endl;
	cout << " internal rate of return = ";
	cout << cash_flow_irr_discrete(times, cflows) << endl;

	return 0;
}

