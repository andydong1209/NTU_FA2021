//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
#include "fin_recipes.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

using namespace std;

TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    this->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
	vector<double> cflows;
	vector<double> times;

	cflows.push_back(Edit1->Text.ToDouble());  times.push_back(Edit2->Text.ToDouble());
	cflows.push_back(Edit3->Text.ToDouble());  times.push_back(Edit4->Text.ToDouble());
	cflows.push_back(Edit5->Text.ToDouble());  times.push_back(Edit6->Text.ToDouble());

	double r = Edit7->Text.ToDouble();

    double NPV = cash_flow_pv_discrete(times, cflows, r);
    double IRR = cash_flow_irr_discrete(times, cflows);

    Edit8->Text = FloatToStr(NPV);
    Edit9->Text = FloatToStr(IRR);
}
//---------------------------------------------------------------------------

