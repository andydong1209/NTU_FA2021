﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DHestonModel
{
    public class MathFunction
    {
        // The double trapezoidal rule
        public static double DoubleTrapz(double[] X, double[] Y)
        {
            int nX = X.Length;
            int nY = Y.Length;
            double a, b, c, d;
            double sumInt = 0.0;
            for (int y = 1; y <= nY - 1; y++)
            {
                a = Y[y - 1];
                b = Y[y];
                for (int x = 1; x <= nX - 1; x++)
                {
                    c = X[x - 1];
                    d = X[x];
                    double term1 = f(a, c) + f(a, d) + f(b, c) + f(b, d);
                    double term2 = f((a + b) / 2.0, c) + f((a + b) / 2.0, d) + f(a, (c + d) / 2.0) + f(b, (c + d) / 2.0);
                    double term3 = f((a + b) / 2.0, (c + d) / 2.0);
                    sumInt += (b - a) * (d - c) / 16.0 * (term1 + 2.0 * term2 + 4.0 * term3);
                }
            }
            return sumInt;
        }

        // The standard normal bivariate CDF
        private static double f(double x, double y)
        {
            double pi = Math.PI;
            return Math.Exp(-0.5 * (x * x + y * y)) / 2.0 / pi;
        }

        // Random number in (a,b) ==========================================================
        public static readonly Random U = new Random(1234);
        public static readonly object sync = new object();
        public static double RandomNum(double a, double b)
        {
            int divisor = 1000000000;
            lock (sync) { return a + (b - a) * U.Next(0, divisor) / divisor; }
        }
    
    }

    public class MiscFunctions
    {
        // Random number in (a,b) ==========================================================
        public readonly Random U = new Random(1234);
        public readonly object sync = new object();
        public double RandomNum(double a, double b)
        {
            int divisor = 1000000000;
            lock (sync) { return a + (b - a) * U.Next(0, divisor) / divisor; }
        }

        // Random integer in (a,b) ==========================================================
        public readonly Random U1 = new Random(4321);
        public readonly object sync1 = new object();
        public int RandomInt(int a, int b)
        {
            lock (sync1) { return U1.Next(a, b); }
        }

        // Random permutation of a vector of integers  =======================================
        public int[] RandomPerm(int[] a)
        {
            int N = a.Length;
            int[][] F = new int[N][];
            for (int i = 0; i <= N - 1; i++)
                F[i] = new int[2] { 0, 0 };
            for (int j = 0; j <= N - 1; j++)
            {
                for (int i = 0; i <= N - 1; i++)
                {
                    F[j][0] = RandomInt(0, 100);
                    F[j][1] = j;
                }
            }
            // Sort the F array w.r.t column 0
            int column = 0;
            Array.Sort(F, delegate(int[] w1, int[] w2)
            {
                return (w1[column] as IComparable).CompareTo(w2[column]);
            });
            int[] b = new int[N];
            for (int j = 0; j <= N - 1; j++)
                b[j] = F[j][1];
            return b;
        }

        // Vector of integers with one of the indices removed
        public int[] RemoveIndex(int[] a, int position)
        {
            int N = a.Length;
            int[] b = new int[N - 1];
            if (position == 0)
            {
                for (int i = 1; i <= N - 1; i++)
                    b[i - 1] = a[i];
            }
            else if (position == N - 1)
            {
                for (int i = 0; i <= N - 2; i++)
                    b[i] = a[i];
            }
            else
            {
                for (int i = 0; i <= position - 1; i++)
                    b[i] = a[i];
                for (int i = position; i <= N - 2; i++)
                    b[i] = a[i + 1];
            }
            return b;
        }
    }


    public class GaussLaguerreFunc
    {
        public struct SturmRoots
        {
            public int NRoots;
            public List<double> StartInt;
            public List<double> EndInt;
        }

        public struct XW
        {
            public double[] abscissas;
            public double[] weights;
        }

        // Gauss Laguerre abscissas and weights
        public static XW GaussLaguerre(int n, double a, double b, int nI, double Tol, int MaxIter)
        {
            // The Laguerre polynomial
            double[] L = new double[n + 1];
            for (int k = 0; k <= n; k++)
                L[k] = Math.Pow(-1.0, Convert.ToDouble(k)) * nchoosek(n, k) / factorial(k);

            // Find the roots
            double[] x = findroot(L, a, b, nI, Tol, MaxIter);

            // Find the weights
            double[,] dL = new double[n, n];
            double[] w = new double[n];
            double[] sumdL = new double[n];
            for (int j = 0; j <= n - 1; j++)
            {
                sumdL[j] = 0.0;
                for (int k = 0; k <= n - 1; k++)
                {
                    dL[k, j] = Math.Pow(-1.0, Convert.ToDouble(k + 1)) / factorial(k) * nchoosek(n, k + 1) * Math.Pow(x[j], k);
                    sumdL[j] += dL[k, j];
                }
                w[j] = 1.0 / x[j] / (sumdL[j] * sumdL[j]);
                w[j] = w[j] * Math.Exp(x[j]);
            }

            // Output the results
            XW output;
            output.abscissas = x;
            output.weights = w;
            return output;
        }

        // Find roots of a polynomial
        public static double[] findroot(double[] C, double a, double b, int nI, double Tol, int MaxIter)
        {
            // Find the Sturm sequence
            double[][] Sturm = sturm(C);
            int nS = C.Length;

            // Find the signs of the Sturm sequences over intervals
            SturmRoots sr = findintervals(a, b, nI, C, Sturm, nS);

            // Number of roots and start/end of the intervals where the polynomial changes sign
            int NRoots = sr.NRoots;
            List<double> StartInt = sr.StartInt;
            List<double> EndInt = sr.EndInt;

            // Apply the bisection algorithm to find the roots
            double[] root = new double[NRoots];
            for (int i = 0; i <= NRoots - 1; i++)
            {
                a = StartInt[i];
                b = EndInt[i];
                root[i] = Bisection(C, a, b, Tol, MaxIter);
            }
            return root;
        }

        // Find the intervals containing the roots of the polynomials using Sturm sequences
        public static SturmRoots findintervals(double a, double b, int nI, double[] C, double[][] Sturm, int nS)
        {
            // Define the intervals along the x-axis
            double[] I = new double[nI];
            double increment = (b - a) / Convert.ToDouble(nI);
            for (int i = 0; i <= nI - 1; i++)
                I[i] = a + Convert.ToDouble(i) * increment;

            // Find the sign changes of the Sturm polynomials
            int M, ListSize = 0, Roots = 0;
            int[] Count = new int[nI];
            int[,] SignCoeff = new int[nI, nS];
            double coeff = 0.0;
            for (int i = 0; i <= nI - 1; i++)
            {
                for (int j = 0; j <= nS - 1; j++)
                {
                    coeff = 0.0;
                    M = Sturm[j].Length;
                    for (int k = 0; k <= M - 1; k++)
                    {
                        coeff += Sturm[j][k] * Math.Pow(I[i], Convert.ToDouble(k));
                    }
                    // Sign of the Sturm sequence (-1, 0, or +1)
                    SignCoeff[i, j] = Math.Sign(coeff);
                }
                // Remove zero signs from the Sturm sequence
                List<int> Signs = new List<int>();
                ListSize = 0;
                for (int j = 0; j <= nS - 1; j++)
                {
                    // Find the size of each sign list without zeros
                    if (SignCoeff[i, j] != 0)
                    {
                        Signs.Add(SignCoeff[i, j]);
                        ListSize += 1;
                    }
                }
                for (int k = 1; k <= ListSize - 1; k++)
                {
                    // Count the number of sign changes
                    if (Signs[k] != Signs[k - 1])
                        Count[i] += 1;
                }
                Signs.Clear();
            }
            // Find the number of roots and intervals containing the roots
            List<double> StartInt = new List<double>();
            List<double> EndInt = new List<double>();
            for (int i = 1; i <= nI - 1; i++)
                if (Count[i - 1] != Count[i])
                {
                    Roots += 1;
                    StartInt.Add(I[i - 1]);
                    EndInt.Add(I[i]);
                }

            // List the intervals containg the roots
            Console.WriteLine("Num StartInterval EndInterval");
            Console.WriteLine("------------------------------");
            for (int i = 0; i <= StartInt.Count() - 1; i++)
                Console.WriteLine("{0,2:F0} {1,10:F4} {2,10:F4}", i + 1, StartInt[i], EndInt[i]);
            Console.WriteLine(" ");

            // Output the results into the structure SturmRoots
            SturmRoots output;
            output.NRoots = Roots;
            output.StartInt = StartInt;
            output.EndInt = EndInt;
            return output;
        }

        // Remainder of dividing polynomial P by polynomial Q
        public static double[] polyrem(double[] P, double[] Q)
        {
            // rem = remainder, quo = quotient
            int nP = P.Length - 1;
            int nQ = Q.Length - 1;
            while (nQ >= 0 && Q[nQ] == 0)
                nQ--;
            double[] rem = new double[nP + 1];
            Array.Copy(P, rem, nP + 1);
            double[] quo = new double[P.Length];
            for (int k = nP - nQ; k >= 0; k--)
            {
                quo[k] = rem[nQ + k] / Q[nQ];
                for (int j = nQ + k - 1; j >= k; j--)
                    rem[j] -= quo[k] * Q[j - k];
            }
            for (int j = nQ; j <= nP; j++)
                rem[j] = 0.0;
            return rem;
        }

        // Differentiate a polynomial
        public static double[] polydiff(double[] C)
        {
            int N = C.Length;
            double[] dC = new double[N - 1];
            for (int k = 1; k <= N - 1; k++)
                dC[k - 1] = C[k] * k;
            return dC;
        }
        
        // Sturm sequence of polynomials
        public static double[][] sturm(double[] p)
        {
            int N = p.Length;
            double[][] P = new double[N][];
            P[0] = p;
            P[1] = polydiff(p);
            for (int j = 2; j <= N - 1; j++)
            {
                P[j] = polyrem(P[j - 2], P[j - 1]);
                for (int k = 0; k < P[j].Length; k++)
                    P[j][k] = -P[j][k];
            }
            return P;
        }

        // Evaluate a polynomial
        public static double polyeval(double[] C, double x)
        {
            int N = C.Length;
            double P = C[0];
            for (int i = 1; i <= N - 1; i++)
                P += C[i] * Math.Pow(x, Convert.ToDouble(i));
            return P;
        }

        // Factorial
        public static double factorial(int n)
        {
            if (n == 0)
                return 1.0;
            else
                return n * factorial(n - 1);
        }

        // N choose k
        public static double nchoosek(int n, int k)
        {
            double nck = 1;
            for (int i = 1; i <= k; i++)
                nck *= Convert.ToDouble(n - k + i) / Convert.ToDouble(i);
            return nck;
        }

        // Bisection Algorithm
        public static double Bisection(double[] C, double a, double b, double Tol, int MaxIter)
        {
            double c = 0.0;
            double fc = 0.0;
            double fa = polyeval(C, a);
            double fb = polyeval(C, b);
            for (int x = 0; x <= MaxIter; x++)
            {
                c = (a + b) / 2.0;
                fc = polyeval(C, c);
                if (Math.Abs(fc) < Tol)
                    break;
                else
                {
                    if (fa * fc < 0)
                        b = c;
                    else
                        a = c;
                }
            }
            return c;
        }
    }

    public class GaussLegendreFunc
    {
        public struct SturmRoots
        {
            public int NRoots;
            public List<double> StartInt;
            public List<double> EndInt;
        }

        public struct XW
        {
            public double[] abscissas;
            public double[] weights;
        }
        
        // Gauss Legendre abscissas and weights
        public static XW GaussLegendre(int n, double a, double b, int nI, double Tol, int MaxIter)
        {
            // The Legendre polynomial
            double nn = Convert.ToDouble(n);
            int m = Convert.ToInt16(Math.Floor(nn / 2.0));
            double[] L = new double[m + 1];
            for (int k = 0; k <= m; k++)
                L[k] = Math.Pow(0.5, nn) * Math.Pow(-1.0, k) * factorial(2 * n - 2 * k) / factorial(k) / factorial(n - k) / factorial(n - 2 * k);

            // Fill in the blank powers of L
            double[] P = new double[n + 1];
            for (int k = 0; k <= n; k++)
            {
                if ((k + 1) % 2 == 0)
                    P[n - k] = 0.0;
                else
                    P[n - k] = L[(k + 1) / 2];
            }

            // Find the roots
            double[] x = findroot(P, a, b, nI, Tol, MaxIter);

            // When n is odd, set the middle root to exactly zero
            if (n % 2 == 1)
                x[(n - 1) / 2] = 0.0;

            // Find the weights
            double[,] dC = new double[m + 1, n];
            double[] w = new double[n];
            double[] sumdC = new double[n];
            for (int j = 0; j <= n - 1; j++)
            {
                sumdC[j] = 0.0;
                for (int k = 0; k <= m; k++)
                {
                    dC[k, j] = Math.Pow(0.5, n) * Math.Pow(-1.0, k) * factorial(2 * n - 2 * k) / factorial(k)
                            / factorial(n - k) / factorial(n - 2 * k) * (n - 2 * k) * Math.Pow(x[j], n - 2 * k - 1);
                    sumdC[j] += dC[k, j];
                }
                w[j] = 2.0 / (1 - x[j] * x[j]) / (sumdC[j] * sumdC[j]);
            }

            // Output the results
            XW output;
            output.abscissas = x;
            output.weights = w;
            return output;
        }

        // Find roots of a polynomial
        public static double[] findroot(double[] C, double a, double b, int nI, double Tol, int MaxIter)
        {
            // Find the Sturm sequence
            double[][] Sturm = sturm(C);
            int nS = C.Length;

            // Find the signs of the Sturm sequences over intervals
            SturmRoots sr = findintervals(a, b, nI, C, Sturm, nS);

            // Number of roots and start/end of the intervals
            int NRoots = sr.NRoots;
            List<double> StartInt = sr.StartInt;
            List<double> EndInt = sr.EndInt;

            // Apply the bisection algorithm to find the roots
            double[] root = new double[NRoots];
            for (int i = 0; i <= NRoots - 1; i++)
            {
                a = StartInt[i];
                b = EndInt[i];
                root[i] = Bisection(C, a, b, Tol, MaxIter);
            }
            return root;
        }

        // Find the intervals containing the roots of the polynomials using Sturm sequences
        static SturmRoots findintervals(double a, double b, int nI, double[] C, double[][] Sturm, int nS)
        {
            // Define the intervals along the x-axis
            double[] I = new double[nI];

            double increment = (b - a) / Convert.ToDouble(nI);
            for (int i = 0; i <= nI - 1; i++)
                I[i] = a + Convert.ToDouble(i) * increment;

            // Find the sign changes of the Sturm polynomials
            int M, ListSize = 0, Roots = 0;
            int[] Count = new int[nI];
            int[,] SignCoeff = new int[nI, nS];
            double coeff = 0.0;
            for (int i = 0; i <= nI - 1; i++)
            {
                for (int j = 0; j <= nS - 1; j++)
                {
                    coeff = 0.0;
                    M = Sturm[j].Length;
                    for (int k = 0; k <= M - 1; k++)
                    {
                        coeff += Sturm[j][k] * Math.Pow(I[i], Convert.ToDouble(k));
                    }
                    // Sign of the Sturm sequence (-1, 0, or +1)
                    SignCoeff[i, j] = Math.Sign(coeff);
                }
                // Remove zero signs from the Sturm sequence
                List<int> Signs = new List<int>();
                ListSize = 0;
                for (int j = 0; j <= nS - 1; j++)
                {
                    // Find the size of each sign list without zeros
                    if (SignCoeff[i, j] != 0)
                    {
                        Signs.Add(SignCoeff[i, j]);
                        ListSize += 1;
                    }
                }
                for (int k = 1; k <= ListSize - 1; k++)
                {
                    // Count the number of sign changes
                    if (Signs[k] != Signs[k - 1])
                        Count[i] += 1;
                }
                Signs.Clear();
            }
            // Find the number of roots and intervals containing the roots
            List<double> StartInt = new List<double>();
            List<double> EndInt = new List<double>();
            for (int i = 1; i <= nI - 1; i++)
                if (Count[i - 1] != Count[i])
                {
                    Roots += 1;
                    StartInt.Add(I[i - 1]);
                    EndInt.Add(I[i]);
                }

            // Output the results into the structure SturmRoots
            SturmRoots output;
            output.NRoots = Roots;
            output.StartInt = StartInt;
            output.EndInt = EndInt;
            return output;
        }

        // Remainder of dividing polynomial P by polynomial Q
        static double[] polyrem(double[] P, double[] Q)
        {
            // rem = remainder, quo = quotient
            int nP = P.Length - 1;
            int nQ = Q.Length - 1;
            while (nQ >= 0 && Q[nQ] == 0)
                nQ--;
            double[] rem = new double[nP + 1];
            Array.Copy(P, rem, nP + 1);
            double[] quo = new double[P.Length];
            for (int k = nP - nQ; k >= 0; k--)
            {
                quo[k] = rem[nQ + k] / Q[nQ];
                for (int j = nQ + k - 1; j >= k; j--)
                    rem[j] -= quo[k] * Q[j - k];
            }
            for (int j = nQ; j <= nP; j++)
                rem[j] = 0.0;
            return rem;
        }

        // Differentiate a polynomial
        static double[] polydiff(double[] C)
        {
            int N = C.Length;
            double[] dC = new double[N - 1];
            for (int k = 1; k <= N - 1; k++)
                dC[k - 1] = C[k] * k;
            return dC;
        }

        // Sturm sequence of polynomials
        static double[][] sturm(double[] p)
        {
            int Order = p.Length;
            double[][] P = new double[Order][];
            P[0] = p;
            P[1] = polydiff(p);
            for (int j = 2; j <= Order - 1; j++)
            {
                P[j] = polyrem(P[j - 2], P[j - 1]);
                for (int k = 0; k < P[j].Length; k++)
                    P[j][k] = -P[j][k];
            }
            return P;
        }

        // Evaluate a polynomial
        static double polyeval(double[] C, double x)
        {
            int N = C.Length;
            double P = C[0];
            for (int i = 1; i <= N - 1; i++)
                P += C[i] * Math.Pow(x, Convert.ToDouble(i));
            return P;
        }

        // Factorial
        static double factorial(int n)
        {
            if (n == 0)
                return 1.0;
            else
                return n * factorial(n - 1);
        }

        // N choose k
        static double nchoosek(int n, int k)
        {
            double nck = 1;
            for (int i = 1; i <= k; i++)
                nck *= Convert.ToDouble(n - k + i) / Convert.ToDouble(i);
            return nck;
        }

        // Bisection Algorithm
        static double Bisection(double[] C, double a, double b, double Tol, int MaxIter)
        {
            double c = 0.0;
            double fc = 0.0;
            double fa = polyeval(C, a);
            double fb = polyeval(C, b);
            for (int x = 0; x <= MaxIter; x++)
            {
                c = (a + b) / 2.0;
                fc = polyeval(C, c);
                if (Math.Abs(fc) < Tol)
                    break;
                else
                {
                    if (fa * fc < 0)
                        b = c;
                    else
                        a = c;
                }
            }
            return c;
        }
    }

    public class GaussLobattoFunc
    {
        public struct SturmRoots
        {
            public int NRoots;
            public List<double> StartInt;
            public List<double> EndInt;
        }

        public struct XW
        {
            public double[] abscissas;
            public double[] weights;
        }

        // Gauss Legendre abscissas and weights
        public static XW GaussLobatto(int N, double a, double b, int nI, double Tol, int MaxIter)
        {
            // The Legendre polynomial
            int n = N - 1;
            int m = Convert.ToInt16(Math.Floor(n / 2.0));
            double[] L = new double[m + 1];
            double[] dL = new double[m + 1];
            for (int k = 0; k <= m; k++)
            {
                L[k] = Math.Pow(0.5, n) * Math.Pow(-1.0, k) * factorial(2 * n - 2 * k) / factorial(k)
                      / factorial(n - k) / factorial(n - 2 * k);
                dL[k] = Math.Pow(0.5, n) * Math.Pow(-1.0, k) * factorial(2 * n - 2 * k) / factorial(k)
                      / factorial(n - k) / factorial(n - 2 * k) * (n - 2 * k);
            }

            // Fill in the blank powers of L
            double[] P = new double[n + 1];
            double[] dP = new double[n + 1];
            for (int k = 0; k <= n; k++)
            {
                if ((k + 1) % 2 == 0)
                {
                    P[n - k] = 0.0;
                    dP[n - k] = dL[k / 2];
                }
                else
                {
                    P[n - k] = L[(k + 1) / 2];
                    dP[n - k] = 0.0;
                }
            }

            // Find the roots
            double[] x = findroot(dP, a, b, nI, Tol, MaxIter);

            // When n is odd, set the middle root to exactly zero
            if ((n - 1) % 2 == 1)
                x[(n - 1) / 2] = 0.0;

            // Create the abscissas by augmenting the endpoints with -1 and +1
            int R = x.Length;
            double[] X = new double[R + 2];
            X[0] = -1.0;
            X[R + 1] = 1.0;
            for (int k = 1; k <= R; k++)
                X[k] = x[k - 1];

            // Find the weights
            double[] Poly = new double[n + 1];
            double[] w = new double[n + 1];
            double sumPoly;
            for (int j = 1; j <= n; j++)
            {
                sumPoly = 0.0;
                for (int k = 0; k <= n; k++)
                {
                    Poly[k] = P[n - k] * Math.Pow(X[j], n - k);
                    sumPoly += Poly[k];
                }
                w[j] = 2.0 / N / (N - 1) / (sumPoly * sumPoly);
            }
            w[0] = 2.0 / N / (N - 1);
            w[n] = w[0];

            // Output the results
            XW output;
            output.abscissas = X;
            output.weights = w;
            return output;
        }

        // Find roots of a polynomial
        public static double[] findroot(double[] C, double a, double b, int nI, double Tol, int MaxIter)
        {
            // Find the Sturm sequence
            double[][] Sturm = sturm(C);
            int nS = C.Length;

            // Find the signs of the Sturm sequences over intervals
            SturmRoots sr = findintervals(a, b, nI, C, Sturm, nS);

            // Number of roots and start/end of the intervals
            int NRoots = sr.NRoots;
            List<double> StartInt = sr.StartInt;
            List<double> EndInt = sr.EndInt;

            // Apply the bisection algorithm to find the roots
            double[] root = new double[NRoots];
            for (int i = 0; i <= NRoots - 1; i++)
            {
                a = StartInt[i];
                b = EndInt[i];
                root[i] = Bisection(C, a, b, Tol, MaxIter);
            }
            return root;
        }

        // Find the intervals containing the roots of the polynomials using Sturm sequences
        static SturmRoots findintervals(double a, double b, int nI, double[] C, double[][] Sturm, int nS)
        {
            // Define the intervals along the x-axis
            double[] I = new double[nI];

            double increment = (b - a) / Convert.ToDouble(nI);
            for (int i = 0; i <= nI - 1; i++)
                I[i] = a + Convert.ToDouble(i) * increment;

            // Find the sign changes of the Sturm polynomials
            int M, ListSize = 0, Roots = 0;
            int[] Count = new int[nI];
            int[,] SignCoeff = new int[nI, nS];
            double coeff = 0.0;
            for (int i = 0; i <= nI - 1; i++)
            {
                for (int j = 0; j <= nS - 1; j++)
                {
                    coeff = 0.0;
                    M = Sturm[j].Length;
                    for (int k = 0; k <= M - 1; k++)
                    {
                        coeff += Sturm[j][k] * Math.Pow(I[i], Convert.ToDouble(k));
                    }
                    // Sign of the Sturm sequence (-1, 0, or +1)
                    SignCoeff[i, j] = Math.Sign(coeff);
                }
                // Remove zero signs from the Sturm sequence
                List<int> Signs = new List<int>();
                ListSize = 0;
                for (int j = 0; j <= nS - 1; j++)
                {
                    // Find the size of each sign list without zeros
                    if (SignCoeff[i, j] != 0)
                    {
                        Signs.Add(SignCoeff[i, j]);
                        ListSize += 1;
                    }
                }
                for (int k = 1; k <= ListSize - 1; k++)
                {
                    // Count the number of sign changes
                    if (Signs[k] != Signs[k - 1])
                        Count[i] += 1;
                }
                Signs.Clear();
            }
            // Find the number of roots and intervals containing the roots
            List<double> StartInt = new List<double>();
            List<double> EndInt = new List<double>();
            for (int i = 1; i <= nI - 1; i++)
                if (Count[i - 1] != Count[i])
                {
                    Roots += 1;
                    StartInt.Add(I[i - 1]);
                    EndInt.Add(I[i]);
                }

            // Output the results into the structure SturmRoots
            SturmRoots output;
            output.NRoots = Roots;
            output.StartInt = StartInt;
            output.EndInt = EndInt;
            return output;
        }

        // Remainder of dividing polynomial P by polynomial Q
        static double[] polyrem(double[] P, double[] Q)
        {
            // rem = remainder, quo = quotient
            int nP = P.Length - 1;
            int nQ = Q.Length - 1;
            while (nQ >= 0 && Q[nQ] == 0)
                nQ--;
            double[] rem = new double[nP + 1];
            Array.Copy(P, rem, nP + 1);
            double[] quo = new double[P.Length];
            for (int k = nP - nQ; k >= 0; k--)
            {
                quo[k] = rem[nQ + k] / Q[nQ];
                for (int j = nQ + k - 1; j >= k; j--)
                    rem[j] -= quo[k] * Q[j - k];
            }
            for (int j = nQ; j <= nP; j++)
                rem[j] = 0.0;
            return rem;
        }

        // Differentiate a polynomial
        static double[] polydiff(double[] C)
        {
            int N = C.Length;
            double[] dC = new double[N - 1];
            for (int k = 1; k <= N - 1; k++)
                dC[k - 1] = C[k] * k;
            return dC;
        }

        // Sturm sequence of polynomials
        static double[][] sturm(double[] p)
        {
            int Order = p.Length;
            double[][] P = new double[Order][];
            P[0] = p;
            P[1] = polydiff(p);
            for (int j = 2; j <= Order - 1; j++)
            {
                P[j] = polyrem(P[j - 2], P[j - 1]);
                for (int k = 0; k < P[j].Length; k++)
                    P[j][k] = -P[j][k];
            }
            return P;
        }

        // Evaluate a polynomial
        static double polyeval(double[] C, double x)
        {
            int N = C.Length;
            double P = C[0];
            for (int i = 1; i <= N - 1; i++)
                P += C[i] * Math.Pow(x, Convert.ToDouble(i));
            return P;
        }

        // Factorial
        static double factorial(int n)
        {
            if (n == 0)
                return 1.0;
            else
                return n * factorial(n - 1);
        }

        // N choose k
        static double nchoosek(int n, int k)
        {
            double nck = 1;
            for (int i = 1; i <= k; i++)
                nck *= Convert.ToDouble(n - k + i) / Convert.ToDouble(i);
            return nck;
        }

        // Bisection Algorithm
        static double Bisection(double[] C, double a, double b, double Tol, int MaxIter)
        {
            double c = 0.0;
            double fc = 0.0;
            double fa = polyeval(C, a);
            double fb = polyeval(C, b);
            for (int x = 0; x <= MaxIter; x++)
            {
                c = (a + b) / 2.0;
                fc = polyeval(C, c);
                if (Math.Abs(fc) < Tol)
                    break;
                else
                {
                    if (fa * fc < 0)
                        b = c;
                    else
                        a = c;
                }
            }
            return c;
        }
    }

    

}

