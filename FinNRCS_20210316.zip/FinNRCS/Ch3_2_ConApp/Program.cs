﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DFinNR;

namespace Ch3_2_ConApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Vector CFlows = new Vector(3);
            Vector Times = new Vector(3);

            CFlows[0] = -100.0;
            CFlows[1] = 75.0;
            CFlows[2] = 75.0;

            Times[0] = 0.0;
            Times[1] = 1.0;
            Times[2] = 2.0;

            double r = 0.1;

            double NPV = PresentValue.cash_flow_pv_discrete(Times, CFlows, r);
            Console.WriteLine("NPV = " + NPV.ToString("F4"));

            Console.ReadKey();
        }
    }
}
