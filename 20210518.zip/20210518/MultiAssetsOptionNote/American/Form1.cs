﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Diagnostics;

using DFinMath;

namespace American
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MersenneTwister MT = new MersenneTwister(1234);
            Stopwatch SW = new Stopwatch();
            SW.Start();

            int NumAsset = 3;
            int NPath = 16;
            int MStep = 10;

            double S1 = 40.0;
            double S2 = 40.0;
            double S3 = 40.0;
            double K = 45.0;

            double sig1 = 0.2;
            double sig2 = 0.3;
            double sig3 = 0.5;
            double rate = 0.05;
            double corr = 0.0;

            int Month = 4;
            double TTM = Month / 12.0;
            //MStep = Month * 30;
            MStep = 10;
            double dt = TTM / MStep;
            

            Matrix MCorr = new Matrix(3, 3, corr);
            for (int i = 0; i < NumAsset; i++)
            {
                MCorr[i, i] = 1.0;
            }

            Matrix MLow = MatrixUtilities.CholeskyDecomposition(MCorr, true);
            //listBox1.Items.Add(MLow.ToString());

            List<Matrix> LMS = new List<Matrix>(0);

            Matrix MS1 = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MS2 = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MS3 = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MSt = new Matrix(NPath, MStep + 1, 0.0);

            Matrix MValue = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MExer = new Matrix(NPath, MStep + 1, 0.0);
            Matrix MHold = new Matrix(NPath, MStep + 1, 0.0);

            for (int i = 0; i < NPath; i++)
            {
                MS1[i, 0] = S1;
                MS2[i, 0] = S2;
                MS3[i, 0] = S3;
                MSt[i, 0] = Math.Max(Math.Max(MS1[i, 0], MS2[i, 0]), MS3[i, 0]);
                for (int k = 0; k < MStep; k++)
                {
                    double n1 = DStat.N_Inv(MT.NextDouble());
                    double n2 = DStat.N_Inv(MT.NextDouble());
                    double n3 = DStat.N_Inv(MT.NextDouble());

                    double e1 = n1 * MLow[0, 0];
                    double e2 = n1 * MLow[1, 0] + n2 * MLow[1, 1];
                    double e3 = n1 * MLow[2, 0] + n2 * MLow[2, 1] + n3 * MLow[2, 2];

                    MS1[i, k + 1] = MS1[i, k] * Math.Exp((rate - 0.5 * sig1 * sig1) * dt 
                        + sig1 * Math.Sqrt(dt) * e1);
                    MS2[i, k + 1] = MS2[i, k] * Math.Exp((rate - 0.5 * sig2 * sig2) * dt 
                        + sig2 * Math.Sqrt(dt) * e2);
                    MS3[i, k + 1] = MS3[i, k] * Math.Exp((rate - 0.5 * sig3 * sig3) * dt 
                        + sig3 * Math.Sqrt(dt) * e3);

                    double MaxST = Math.Max(Math.Max(MS1[i, k + 1], MS2[i, k + 1]), MS3[i, k + 1]);
                    MSt[i, k + 1] = MaxST;
                    MExer[i, k + 1] = Math.Max(0.0, K - MaxST);
                }                
            }

            #region Terminal_Step10

            int j;
            int OBS;
            int dim = 4; 
            double disc = Math.Exp(-rate * dt);
            Matrix MY;
            Matrix MX;
            {
                j = MStep;
                for (int i = 0; i < NPath; i++)
                {
                    MValue[i, j] = MExer[i, j];
                }
                
                listBox1.Items.Add("----Time 10 St  ----");
                listBox2.Items.Add("----Time 10 Exer Value----");
                listBox4.Items.Add("----Time 10 Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox1.Items.Add(MSt[i, j].ToString());
                    listBox2.Items.Add(MExer[i, j].ToString());
                    listBox4.Items.Add(MValue[i, j].ToString());
                }
                
            }
            #endregion

            List<int> RegPath;

            #region Step09
            {
                j = 9;
                RegPath = new List<int>(0);
                for (int i = 0; i < NPath; i++)
                {
                    if (MExer[i, j] > 0)
                    {
                        RegPath.Add(i);
                    }
                }

                
                listBox1.Items.Add("----Time 9 St  ----");
                listBox2.Items.Add("----Time 9 Exer Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox1.Items.Add(MSt[i, j].ToString());
                    listBox2.Items.Add(MExer[i, j].ToString());
                }

                listBox3.Items.Add("----Time 9 RegPath----");
                for (int i = 0; i < RegPath.Count; i++)
                {
                    listBox3.Items.Add(RegPath[i].ToString());
                }
                

                OBS = RegPath.Count;
                MY = new Matrix(OBS, 1);
                MX = new Matrix(OBS, dim);

                for (int i = 0; i < OBS; i++)
                {
                    int obs = RegPath[i];

                    MY[i, 0] = MValue[obs, j + 1] * disc;

                    MX[i, 0] = 1.0;
                    
                    MX[i, 1] = MSt[obs, j];
                    MX[i, 2] = MSt[obs, j] * MSt[obs, j];
                    MX[i, 3] = MSt[obs, j] * MSt[obs, j] * MSt[obs, j];
                    
                    /*
                    MX[i, 1] = MS1[obs, j];
                    MX[i, 2] = MS2[obs, j];
                    MX[i, 3] = MS3[obs, j];
                    MX[i, 4] = MS1[obs, j] * MS1[obs, j];
                    MX[i, 5] = MS2[obs, j] * MS2[obs, j];
                    MX[i, 6] = MS3[obs, j] * MS3[obs, j];
                    MX[i, 7] = MS1[obs, j] * MS2[obs, j];
                    MX[i, 8] = MS1[obs, j] * MS3[obs, j];
                    MX[i, 9] = MS2[obs, j] * MS3[obs, j];
                    */
                }

                Matrix MXT = new Matrix(Matrix.transpose(MX));
                Matrix MA = new Matrix(MXT * MX);
                Matrix MAI = new Matrix(Matrix.inverse(MA));
                Matrix MC = new Matrix(MXT * MY);
                Matrix MB = new Matrix(MAI * MC);

                
                listBox3.Items.Add("----Time 9 Beta----");
                for (int i = 0; i < dim; i++)
                {
                    listBox3.Items.Add(i.ToString() + ": beat: " + MB[i, 0].ToString("F2"));
                }
                

                for (int i = 0; i < NPath; i++)
                {
                    MValue[i, j] = MValue[i, j + 1] * disc;
                }

                
                listBox1.Items.Add("----Time 9 Hold Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox1.Items.Add(MValue[i, j].ToString());
                }
                

                listBox3.Items.Add("----Time 9 Expect Value----");
                for (int i = 0; i < OBS; i++)
                {
                    int obs = RegPath[i];
                    
                    double Expect = MB[0, 0] * 1.0 + MB[1, 0] * MSt[obs, j]
                        + MB[2, 0] * MSt[obs, j] * MSt[obs, j]
                        + MB[3, 0] * MSt[obs, j] * MSt[obs, j] * MSt[obs, j];
                    
                    /*
                    double Expect = MB[0, 0] * 1.0
                        + MB[1, 0] * MS1[obs, j]
                        + MB[2, 0] * MS2[obs, j]
                        + MB[3, 0] * MS3[obs, j]
                        + MB[4, 0] * MS1[obs, j] * MS1[obs, j]
                        + MB[5, 0] * MS2[obs, j] * MS2[obs, j]
                        + MB[6, 0] * MS3[obs, j] * MS3[obs, j]
                        + MB[7, 0] * MS1[obs, j] * MS2[obs, j]
                        + MB[8, 0] * MS1[obs, j] * MS3[obs, j]
                        + MB[9, 0] * MS2[obs, j] * MS3[obs, j];
                    */

                    listBox3.Items.Add(obs.ToString() + " Path: Expect: " + Expect.ToString("F2"));

                    if (MExer[obs, j] > Expect)
                    {
                        MValue[obs, j] = MExer[obs, j];
                    }
                }

                
                listBox4.Items.Add("----Time 9 Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox4.Items.Add(MValue[i, j].ToString());
                }
                
            }
            #endregion step09


            #region Step08_01
            for(j = 8; j > 0; j--)
            {                
                RegPath = new List<int>(0);
                for (int i = 0; i < NPath; i++)
                {
                    if (MExer[i, j] > 0)
                    {
                        RegPath.Add(i);
                    }
                }

                /*
                //listBox1.Items.Add("----Time 9 St  ----");
                //listBox2.Items.Add("----Time 9 Exer Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox1.Items.Add(MSt[i, j].ToString());
                    listBox2.Items.Add(MExer[i, j].ToString());
                }

                //listBox3.Items.Add("----Time 9 RegPath----");
                for (int i = 0; i < RegPath.Count; i++)
                {
                    listBox3.Items.Add(RegPath[i].ToString());
                }
                */

                OBS = RegPath.Count;
                MY = new Matrix(OBS, 1);
                MX = new Matrix(OBS, dim);

                for (int i = 0; i < OBS; i++)
                {
                    int obs = RegPath[i];

                    MY[i, 0] = MValue[obs, j + 1] * disc;
                    
                    MX[i, 0] = 1.0;
                    MX[i, 1] = MSt[obs, j];
                    MX[i, 2] = MSt[obs, j] * MSt[obs, j];
                    MX[i, 3] = MSt[obs, j] * MSt[obs, j] * MSt[obs, j];
                    
                    /*
                    MX[i, 1] = MS1[obs, j];
                    MX[i, 2] = MS2[obs, j];
                    MX[i, 3] = MS3[obs, j];
                    MX[i, 4] = MS1[obs, j] * MS1[obs, j];
                    MX[i, 5] = MS2[obs, j] * MS2[obs, j];
                    MX[i, 6] = MS3[obs, j] * MS3[obs, j];
                    MX[i, 7] = MS1[obs, j] * MS2[obs, j];
                    MX[i, 8] = MS1[obs, j] * MS3[obs, j];
                    MX[i, 9] = MS2[obs, j] * MS3[obs, j];
                    */
                }

                Matrix MXT = new Matrix(Matrix.transpose(MX));
                Matrix MA = new Matrix(MXT * MX);
                Matrix MAI = new Matrix(Matrix.inverse(MA));
                Matrix MC = new Matrix(MXT * MY);
                Matrix MB = new Matrix(MAI * MC);

                /*
                listBox3.Items.Add("----Time 9 Beta----");
                for (int i = 0; i < dim; i++)
                {
                    listBox3.Items.Add(i.ToString() + ": beat: " + MB[i, 0].ToString("F2"));
                }
                */

                for (int i = 0; i < NPath; i++)
                {
                    MValue[i, j] = MValue[i, j + 1] * disc;
                }

                /*
                listBox1.Items.Add("----Time 9 Hold Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox1.Items.Add(MValue[i, j].ToString());
                }
                */

                //listBox3.Items.Add("----Time 9 Expect Value----");
                for (int i = 0; i < OBS; i++)
                {
                    int obs = RegPath[i];
                                        
                    double Expect = MB[0, 0] * 1.0 + MB[1, 0] * MSt[obs, j]
                        + MB[2, 0] * MSt[obs, j] * MSt[obs, j]
                        + MB[3, 0] * MSt[obs, j] * MSt[obs, j] * MSt[obs, j];                    

                    /*
                    double Expect = MB[0, 0] * 1.0
                        + MB[1, 0] * MS1[obs, j]
                        + MB[2, 0] * MS2[obs, j]
                        + MB[3, 0] * MS3[obs, j]
                        + MB[4, 0] * MS1[obs, j] * MS1[obs, j]
                        + MB[5, 0] * MS2[obs, j] * MS2[obs, j]
                        + MB[6, 0] * MS3[obs, j] * MS3[obs, j]
                        + MB[7, 0] * MS1[obs, j] * MS2[obs, j]
                        + MB[8, 0] * MS1[obs, j] * MS3[obs, j]
                        + MB[9, 0] * MS2[obs, j] * MS3[obs, j];
                    */

                    //listBox3.Items.Add(obs.ToString() + " Path: Expect: " + Expect.ToString("F2"));

                    if (MExer[obs, j] > Expect)
                    {
                        MValue[obs, j] = MExer[obs, j];
                    }
                }

                /*
                listBox4.Items.Add("----Time 9 Value----");
                for (int i = 0; i < NPath; i++)
                {
                    listBox4.Items.Add(MValue[i, j].ToString());
                }
                */
            }
            #endregion Step08_01

            double Sum = 0;
            for(int i=0; i<NPath; i++)
            {
                Sum = Sum + MValue[i, 1];
            }

            double C0 = Sum / NPath * Math.Exp(-rate * dt);
            SW.Stop();

            textBox1.Text = C0.ToString();
            textBox2.Text = SW.ElapsedMilliseconds.ToString();
        }
    }
}
