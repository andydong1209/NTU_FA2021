﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QLNet
{
    public class ConstantSwaptionVolatility : SwaptionVolatilityStructure
    {
        private Handle<Quote> volatility_;
        private Period maxSwapTenor_;

        // floating reference date, floating market data
        public ConstantSwaptionVolatility(int settlementDays, Calendar cal, 
            BusinessDayConvention bdc, Handle<Quote> vol, DayCounter dc) 
            : base(settlementDays, cal, bdc, dc)
        {            
            volatility_ = vol;
            maxSwapTenor_ = new Period(100, TimeUnit.Years);

            volatility_.registerWith(update);
        }

        //! fixed reference date, floating market data
        public ConstantSwaptionVolatility(Date referenceDate, Calendar cal, 
            BusinessDayConvention bdc, Handle<Quote> vol, DayCounter dc) 
            : base(referenceDate, cal, bdc, dc)
        {
            volatility_ = vol;
            maxSwapTenor_ = new Period(100, TimeUnit.Years);
            
            volatility_.registerWith(update);
        }

        // floating reference date, fixed market data
        public ConstantSwaptionVolatility(int settlementDays, Calendar cal, 
            BusinessDayConvention bdc, double vol, DayCounter dc) 
            : base(settlementDays, cal, bdc, dc)
        {
            volatility_ = new Handle<Quote>(new SimpleQuote(vol));
            maxSwapTenor_ = new Period(100, TimeUnit.Years);
        }

        //! fixed reference date, fixed market data
        public ConstantSwaptionVolatility(Date referenceDate, Calendar cal, 
            BusinessDayConvention bdc, double vol, DayCounter dc) 
            : base(referenceDate, cal, bdc, dc)
        {
            volatility_ = new Handle<Quote>(new SimpleQuote(vol));
            maxSwapTenor_ = new Period(100, TimeUnit.Years);
        }

        protected override SmileSection smileSectionImpl(Date d, Period period)
        {
            double atmVol = volatility_.link.value();
            return new FlatSmileSection(d, atmVol, dayCounter(), referenceDate());
        }

        protected override SmileSection smileSectionImpl(double optionTime, double x)
        {
            double atmVol = volatility_.link.value();
            return new FlatSmileSection(optionTime, atmVol, dayCounter());
        }

        protected override double volatilityImpl(Date date, Period period, double x)
        {
            return volatility_.link.value();
        }

        protected override double volatilityImpl(double x, double y, double z)
        {
            return volatility_.link.value();
        }
        
        //! \name TermStructure interface        
        public override Date maxDate()
        {
            return Date.maxDate();
        }
                
        //! \name VolatilityTermStructure interface        
        public override double minStrike()
        {
            return double.Epsilon;
        }
        public override double maxStrike()
        {
            return double.MaxValue;
        }
                
        //! \name SwaptionVolatilityStructure interface        
        public override Period maxSwapTenor()
        {
            return maxSwapTenor_;
        }
    }
}
