﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QLNet
{
    //! Black-formula swaption engine
    /*! \ingroup swaptionengines

        \warning The engine assumes that the exercise date equals the
                 start date of the passed swap.
    */
    public class BlackSwaptionEngine : Swaption.engine
    {
	    private Handle<YieldTermStructure> termStructure_;
        private Handle<SwaptionVolatilityStructure> volatility_;

        public Handle<YieldTermStructure> termStructure()
        {
            return termStructure_;
        }
        public Handle<SwaptionVolatilityStructure> volatility()
        {
            return volatility_;
        }

        public BlackSwaptionEngine(Handle<YieldTermStructure> termStructure, double vol) 
            : this(termStructure, vol, new Actual365Fixed()) {}
        public BlackSwaptionEngine(Handle<YieldTermStructure> termStructure, double vol,
            DayCounter dc)
        {
            termStructure_ = termStructure;
            volatility_ = new Handle<SwaptionVolatilityStructure>(
                new ConstantSwaptionVolatility(0, new NullCalendar(),
                    BusinessDayConvention.Following, vol, dc));
            
            termStructure_.registerWith(update);
        }

        public BlackSwaptionEngine(Handle<YieldTermStructure> termStructure, Handle<Quote> vol)
            : this(termStructure, vol, new Actual365Fixed()) {}
        public BlackSwaptionEngine(Handle<YieldTermStructure> termStructure, Handle<Quote> vol,
            DayCounter dc)
        {
            termStructure_ = termStructure;
            volatility_ = new Handle<SwaptionVolatilityStructure>(
                new ConstantSwaptionVolatility(0, new NullCalendar(), 
                    BusinessDayConvention.Following, vol, dc));

            termStructure_.registerWith(update);
            volatility_.registerWith(update);
        }

        public BlackSwaptionEngine(Handle<YieldTermStructure> termStructure,
            Handle<SwaptionVolatilityStructure> volatility)
        {
            termStructure_ = termStructure;
            volatility_ = volatility;

            termStructure_.registerWith(update);
            volatility_.registerWith(update);
        }

        public override void calculate()
        {
            const double basisPoint = 1.0e-4;
            Date exerciseDate = arguments_.exercise.date(0);

            // the part of the swap preceding exerciseDate should be truncated
            // to avoid taking into account unwanted cashflows
            VanillaSwap swap = arguments_.swap;
            double strike = swap.fixedRate;

            // using the forecasting curve
            //swap.setPricingEngine(boost::shared_ptr<PricingEngine>(new
			//    DiscountingSwapEngine(swap.iborIndex()->forwardingTermStructure(), false)));
            swap.setPricingEngine(new DiscountingSwapEngine(
                swap.iborIndex().forwardingTermStructure()));

            double atmForward = swap.fairRate();

            // Volatilities are quoted for zero-spreaded swaps.
            // Therefore, any spread on the floating leg must be removed
            // with a corresponding correction on the fixed leg.
            if (swap.spread != 0.0) 
		    {
                double correction = swap.spread 
                    * Math.Abs(swap.floatingLegBPS()/swap.fixedLegBPS());
                strike -= correction;
                atmForward -= correction;
                results_.additionalResults["spreadCorrection"] = correction;
            } 
		    else 
		    {
                results_.additionalResults["spreadCorrection"] = 0.0;
            }        
		    results_.additionalResults["strike"] = strike;
            results_.additionalResults["atmForward"] = atmForward;

            // using the discounting curve
            swap.setPricingEngine(new DiscountingSwapEngine(termStructure_));
		    double annuity = 0;

            switch(arguments_.settlementType) 
		    {
                case Settlement.Type.Physical: 
		        {
			        annuity = Math.Abs(swap.fixedLegBPS())/basisPoint;
			        break;
		        }
                case Settlement.Type.Cash: 
		        {
                    List<CashFlow> fixedLeg = swap.fixedLeg();
                    FixedRateCoupon firstCoupon = (FixedRateCoupon)fixedLeg[0];
	                DayCounter dayCount = firstCoupon.dayCounter();
		            double fixedLegCashBPS = CashFlows.bps(fixedLeg, 
                        new InterestRate(atmForward, dayCount, Compounding.Compounded, 
                            Frequency.Annual), termStructure_.link.referenceDate());

			        annuity = Math.Abs(fixedLegCashBPS/basisPoint);
			        break;
	            }
		        default:
			        Utils.QL_Require(false, "unknown settlement type");
                    break;
		    }
            
            results_.additionalResults["annuity"] = annuity;
            // the swap length calculation might be improved using the value date
            // of the exercise date
            double swapLength =  volatility_.link.swapLength(exerciseDate, 
                arguments_.floatingPayDates.Last());
            results_.additionalResults["swapLength"] = swapLength;

            double variance = volatility_.link.blackVariance(exerciseDate, swapLength, strike);
            double stdDev = Math.Sqrt(variance);
            results_.additionalResults["stdDev"] = stdDev;
            Option.Type w = (arguments_.type == VanillaSwap.Type.Payer) ? 
                Option.Type.Call : Option.Type.Put;
            results_.value = Utils.blackFormula(w, strike, atmForward, stdDev, annuity);

            double exerciseTime = volatility_.link.timeFromReference(exerciseDate);
            results_.additionalResults["vega"] = Math.Sqrt(exerciseTime) *
                Utils.blackFormulaStdDevDerivative(strike, atmForward, stdDev, annuity);
        }
    }
}
