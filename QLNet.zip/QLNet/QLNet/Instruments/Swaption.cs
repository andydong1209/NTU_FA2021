﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QLNet
{    
    //! %settlement information
    public struct Settlement
    {
        public enum Type { Physical, Cash };
    };

    //! %Swaption class
    /*! \ingroup instruments

        \test
        - the correctness of the returned value is tested by checking
          that the price of a payer (resp. receiver) swaption
          decreases (resp. increases) with the strike.
        - the correctness of the returned value is tested by checking
          that the price of a payer (resp. receiver) swaption
          increases (resp. decreases) with the spread.
        - the correctness of the returned value is tested by checking
          it against that of a swaption on a swap with no spread and a
          correspondingly adjusted fixed rate.
        - the correctness of the returned value is tested by checking
          it against a known good value.
        - the correctness of the returned value of cash settled swaptions
          is tested by checking the modified annuity against a value
          calculated without using the Swaption class.

        \todo add greeks and explicit exercise lag
    */
    public class Swaption : Option
    {
        private class ImpliedVolHelper : ISolver1d
        {
            private IPricingEngine engine_;
            private Handle<YieldTermStructure> discountCurve_;
            private double targetValue_;
            private SimpleQuote vol_;
            private Instrument.Results results_;

            public ImpliedVolHelper(Swaption swaption, Handle<YieldTermStructure> discountCurve,
                double targetValue)
            {
                discountCurve_ = discountCurve;
                targetValue_ = targetValue;

                vol_ = new SimpleQuote(-1.0);
                Handle<Quote> h = new Handle<Quote>(vol_);
                engine_ = (IPricingEngine)new BlackSwaptionEngine(discountCurve_, h);
                swaption.setupArguments(engine_.getArguments());
                results_ = engine_.getResults() as Instrument.Results;
            }

            public override double value(double x)
            {
                if (x != vol_.value())
                {
                    vol_.setValue(x);
                    engine_.calculate();
                }
                return results_.value.Value - targetValue_;
            }

            public override double derivative(double x)
            {
                if (x != vol_.value())
                {
                    vol_.setValue(x);
                    engine_.calculate();
                }
                if (!results_.additionalResults.Keys.Contains("vega"))
                    throw new Exception("vega not provided");

                return (double)results_.additionalResults["vega"];
            }
        }    

        // arguments
        //private Exercise exercise_;
        //private Payoff payoff_;        
        private VanillaSwap swap_;   

        // results frm VanillaSwap
        //private double? fairRate_;
        //private double? fairSpread_;
     
        //Handle<YieldTermStructure> termStructure_;
        private Settlement.Type settlementType_;

        public Settlement.Type settlementType() { return settlementType_; }
        public VanillaSwap.Type type() { return swap_.swapType; }
        public VanillaSwap underlyingSwap() { return swap_; }

        public new class Arguments : VanillaSwap.Arguments
        {
            //Properties Inherite from option
            public Payoff payoff;
            public Exercise exercise;

            //Properties Inherit from Swap
            //Properties owned by swaption  
            public VanillaSwap swap;
            public Settlement.Type settlementType;

            public Arguments() 
            {
                settlementType = Settlement.Type.Physical; 
            }
            public override void validate()
            {
                //VanillaSwap.Arguments.validate();
                base.validate();
                Utils.QL_Require(payoff != null, "no payoff given");
                Utils.QL_Require(exercise != null, "no exercise given");
                Utils.QL_Require(swap != null, "vanilla swap not set");
                Utils.QL_Require(exercise != null, "exercise not set");
            }
        }

        public class engine : GenericEngine<Swaption.Arguments, Swaption.Results> { }

        public Swaption(VanillaSwap swap, Exercise exercise) 
            : this(swap, exercise, Settlement.Type.Physical) { }
        public Swaption(VanillaSwap swap, Exercise exercise, Settlement.Type delivery) 
            : base(new Payoff(), exercise)
        {
            swap_ = swap;
            settlementType_ = delivery;
        }

        public override bool isExpired()
        {
            return new Simple_Event(exercise_.dates().Last()).hasOccurred();
        }

        public override void setupArguments(IPricingEngineArguments args)
        {
            swap_.setupArguments(args);          
            Swaption.Arguments arguments = args as Swaption.Arguments;

            Utils.QL_Require(arguments != null, "wrong argument type");
            
            arguments.payoff = payoff_;
            arguments.exercise = exercise_;

            arguments.swap = swap_;
            arguments.settlementType = settlementType_;
            arguments.exercise = exercise_;
        }
       
        //! implied volatility
        public double impliedVolatility(double price, Handle<YieldTermStructure> discountCurve,
            double guess)
        {
            return impliedVolatility(price, discountCurve, guess, 1.0e-4, 100, 1.0e-7,	4.0);
        }

        public double impliedVolatility(double targetValue, 
            Handle<YieldTermStructure> discountCurve, double guess, double accuracy, 
            int maxEvaluations, double minVol, double maxVol)
        {
            calculate();
            Utils.QL_Require(!isExpired(), "instrument expired");

            ImpliedVolHelper f = new ImpliedVolHelper(this, discountCurve, targetValue);
            //Brent solver;
            NewtonSafe solver = new NewtonSafe();
            solver.setMaxEvaluations(maxEvaluations);
            return solver.solve(f, accuracy, guess, minVol, maxVol);
        }
    }
}
