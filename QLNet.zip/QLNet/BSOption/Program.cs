﻿using System;
using System.Collections.Generic;
using QLNet;

namespace BSOption
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime timer = DateTime.Now;

            Calendar calendar = new TARGET();
            Date todayDate = new Date(15, Month.May, 1998);
            Date settlementDate = new Date(17, Month.May, 1998);
            DayCounter dayCounter = new Actual365Fixed();
            Settings.setEvaluationDate(todayDate);

            double underlying = 100;
            double strike = 100;
            double dividendYield = 0.00;
            double riskFreeRate = 0.06;
            double volatility = 0.30;

            Option.Type type = Option.Type.Call;
            Date maturity = new Date(17, Month.May, 1999);
            StrikedTypePayoff payoff = new PlainVanillaPayoff(type, strike);
            Exercise europeanExercise = new EuropeanExercise(maturity);

            SimpleQuote SQuote = new SimpleQuote(underlying);
            Handle<Quote> underlyingH = new Handle<Quote>(SQuote);
            var flatTermStructure = new Handle<YieldTermStructure>(
                new FlatForward(settlementDate, riskFreeRate, dayCounter));
            var flatDividendTS = new Handle<YieldTermStructure>(
                new FlatForward(settlementDate, dividendYield, dayCounter));
            var flatVolTS = new Handle<BlackVolTermStructure>(
                new BlackConstantVol(settlementDate, calendar, volatility, dayCounter));
            var bsmProcess = new BlackScholesMertonProcess(
                underlyingH, flatDividendTS, flatTermStructure, flatVolTS);
            VanillaOption europeanOption = new VanillaOption(payoff, europeanExercise);
            europeanOption.setPricingEngine(new AnalyticEuropeanEngine(bsmProcess));

            string method = "Black-Scholes";
            double premium = europeanOption.NPV();
            double delta = europeanOption.delta();
            double gamma = europeanOption.gamma();
            double vega = europeanOption.vega();
            double theta = europeanOption.theta();
            double rho = europeanOption.rho();

            int[] widths = new int[] { 15, 15, 15, 15, 15 };
            Console.Write("{0, -" + widths[0] + "}", "Method");
            Console.Write("{0, -" + widths[1] + "}", "European");
            Console.WriteLine();

            Console.Write("{0, -" + widths[0] + "}", method);
            Console.Write("{0, -" + widths[1] + ":0.000000}", premium);
            Console.WriteLine();

            Console.Write("{0, -" + widths[0] + "}", "Delta");
            Console.Write("{0, -" + widths[1] + "}", "Gamma");
            Console.Write("{0, -" + widths[2] + "}", "Vega");
            Console.Write("{0, -" + widths[3] + "}", "Theta");
            Console.WriteLine("{0, -" + widths[4] + "}", "Rho");

            Console.Write("{0, -" + widths[0] + ":0.000000}", delta);
            Console.Write("{0, -" + widths[1] + ":0.000000}", gamma);
            Console.Write("{0, -" + widths[2] + ":0.000000}", vega);
            Console.Write("{0, -" + widths[3] + ":0.000000}", theta);
            Console.WriteLine("{0, -" + widths[4] + ":0.000000}\n\n", rho);

            SQuote.setValue(101);
            premium = europeanOption.NPV();
            delta = europeanOption.delta();
            gamma = europeanOption.gamma();
            vega = europeanOption.vega();
            theta = europeanOption.theta();
            rho = europeanOption.rho();

            Console.Write("{0, -" + widths[0] + "}", "Method");
            Console.Write("{0, -" + widths[1] + "}", "European");
            Console.WriteLine();

            Console.Write("{0, -" + widths[0] + "}", method);
            Console.Write("{0, -" + widths[1] + ":0.000000}", premium);
            Console.WriteLine();

            Console.Write("{0, -" + widths[0] + "}", "Delta");
            Console.Write("{0, -" + widths[1] + "}", "Gamma");
            Console.Write("{0, -" + widths[2] + "}", "Vega");
            Console.Write("{0, -" + widths[3] + "}", "Theta");
            Console.WriteLine("{0, -" + widths[4] + "}", "Rho");

            Console.Write("{0, -" + widths[0] + ":0.000000}", delta);
            Console.Write("{0, -" + widths[1] + ":0.000000}", gamma);
            Console.Write("{0, -" + widths[2] + ":0.000000}", vega);
            Console.Write("{0, -" + widths[3] + ":0.000000}", theta);
            Console.WriteLine("{0, -" + widths[4] + ":0.000000}", rho);

            Console.ReadKey();
        }
    }
}
