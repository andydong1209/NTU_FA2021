﻿using System;
using QLNet;

namespace DateTimeCase
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime timer = DateTime.Now;
            Calendar calendar = new Taiwan();
            Date todaysDate = new Date(8, Month.April, 1998);
            Date settlementDate = new Date(10, Month.April, 1998);
            Settings.setEvaluationDate(todaysDate);

            Date bdate = new Date(31, Month.Jan, 2010);
            Date edate = new Date(31, Month.Jul, 2010);
            DayCounter dc = new Actual365Fixed();

            double num = dc.dayCount(bdate, edate);
            double yr = dc.yearFraction(bdate, edate);

            Period pd1 = new Period(1, TimeUnit.Months);
            Frequency f1 = Frequency.Weekly;
            Period pd2 = new Period(f1);

            Date MonthLater = bdate + pd1;
            Date WeekLater = bdate + pd2;

            Console.WriteLine("today: " + todaysDate.ToString());
            Console.WriteLine("settlement: " +
                settlementDate.ToString());

            Console.WriteLine("\nPeriod begin date: " + bdate.ToString()
               + "  end date: " + edate.ToString());
            Console.WriteLine("Number of day: " + num.ToString());
            Console.WriteLine("Year Fraction: " + yr.ToString());

            Date amonth = Date.advance(bdate, 1, TimeUnit.Months);
            Console.WriteLine("\nA Month after begin date: " +
                amonth.ToString());
            Console.WriteLine("A Month after begin date: " +
                MonthLater.ToString());
            Console.WriteLine("A Week after begin date: " +
                WeekLater.ToString());

            Date setdate = Date.nthWeekday(3, DayOfWeek.Friday, 4, 2010);
            Console.WriteLine("\n3rd Friday of April 2010: " +
                setdate.ToString());

            Console.ReadKey();
        }
    }
}
