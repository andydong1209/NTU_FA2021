﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DFinMath;

namespace BSModel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double Asset = 100.0;
            double Strike = 100.0;
            double TTM = 1.0;
            double Sigma = 0.3;
            double Rate = 0.04;
            double Yield = 0.02;
            //double dt = 1.0 / 365.0;

            // Analytic Benchmark
            double d1 = (Math.Log(Asset / Strike)
                + (Rate - Yield + 0.5 * Sigma * Sigma) * TTM)
                / (Sigma * Math.Sqrt(TTM));
            double d2 = d1 - Sigma * Math.Sqrt(TTM);

            double CValue = Asset * Math.Exp(-Yield * TTM) * DStat.NormDist(d1)
                - Strike * Math.Exp(-Rate * TTM) * DStat.NormDist(d2);

            double PValue = Strike * Math.Exp(-Rate * TTM) * DStat.NormDist(-d2)
                - Asset * Math.Exp(-Yield * TTM) * DStat.NormDist(-d1);

            textBox1.Text = CValue.ToString();
            textBox2.Text = PValue.ToString();
        }
    }
}
