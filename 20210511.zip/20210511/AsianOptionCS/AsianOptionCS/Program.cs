﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Diagnostics;

using DFinMath;
namespace AsianOptionCS
{
    class Program
    {
        static void Main(string[] args)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

			int Paths = 10240;
			int Steps = 12;

			double S = 100.0;
			double K = 101.0;
			double T = 1.0;
			double sig = 0.1;
			double r = 0.02;
			double y = 0.01;

			double dt = T / Steps;

			Matrix MSt = new Matrix(Paths, Steps +1);
			Matrix MSA = new Matrix(Paths, 1);
			Matrix MCT = new Matrix(Paths, 1);
		
		    MersenneTwister aMT = new MersenneTwister(1234);
			
			for (int i = 0; i < Paths; i++)
			{
				double sum = 0.0;
				
				MSt[i, 0] = S;
			
				for (int j = 0; j < Steps; j++)
				{
					double n1 = DStat.N_Inv(aMT.NextDouble());
					MSt[i, j + 1] = MSt[i, j] * Math.Exp(((r - y) - (sig * sig) / 2.0) * dt
						+ (sig * Math.Sqrt(dt) * n1));
					sum += MSt[i, j + 1];
					
				}
				MSA[i, 0] = sum / Steps;			
			}

			double PayOff = 0.0;
			for (int i = 0; i < Paths; i++)
			{
				MCT[i, 0] = Math.Max(MSA[i, 0] - K, 0.0);
				
				PayOff += MCT[i, 0];
			}

            sw.Stop();
            Console.WriteLine("Stopwatch Frequency: " + Stopwatch.Frequency.ToString());
            Console.WriteLine("Elasped Ticks: " + sw.ElapsedTicks.ToString());
            Console.WriteLine("Elasped seconds: " + (sw.ElapsedTicks / (double)Stopwatch.Frequency).ToString());

            long frequency = Stopwatch.Frequency;
            Console.WriteLine("  Timer frequency in ticks per second = {0}", frequency);

            long nanosecPerTick = (1000L * 1000L * 1000L) / frequency;
            Console.WriteLine("  Timer is accurate within {0} nanoseconds", nanosecPerTick);

            Console.WriteLine("PayOff = " + PayOff);
			double C0 = PayOff / Paths * Math.Exp(-r * T);
			
			Console.WriteLine("Asian Option NPV = " + C0);
			Console.ReadKey();
			
		}
    }
}
