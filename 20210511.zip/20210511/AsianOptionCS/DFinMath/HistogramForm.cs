﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace DFinMath
{
    public class Histogram : Form
    {
        public Histogram()
        {
            this.Name = "Histogram";
            this.Text = "Histogram";   
         
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 839);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

            this.Paint += new PaintEventHandler(HistogramForm_Paint);                        
        }

        private Vector aNormRV;
        private int binsNum;
        public Histogram(Vector rv, int num) : this()
        {
            aNormRV = new Vector(rv);
            binsNum = num;
            this.Text = "A Normal RV Histogram";
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void HistogramForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();

            int dx = 3;
            Pen p1 = new Pen(Color.Black, dx);
            Pen p2 = new Pen(Color.Blue, dx);
            Pen p3 = new Pen(Color.Red, 2);

            int width = this.ClientSize.Width;
            int height = this.ClientSize.Height;
            int x0 = width / 2;
            int y0 = height;
            int xmax = x0;
            int ymax = y0;

            g.DrawRectangle(p2, 0, 0, width - 2, height - 2);

            double max = aNormRV.Max();
            double min = aNormRV.Min();
            double diff = (max - min) / (binsNum);

            List<int> freq = new List<int>();
            List<int> Index = new List<int>();
            aNormRV.Sort();

            for (int i = 1; i <= binsNum; i++)
            {
                Index.Add(aNormRV.FindIndex(x => x > (min + i * diff)));
            }

            freq.Add(Index[0]);
            for (int i = 1; i < binsNum - 1; i++)
            {
                freq.Add(Index[i] - Index[i - 1]);
            }
            freq.Add(aNormRV.Count - Index[binsNum - 2]);

            int Sum = freq.Sum();

            int maxFreq = freq.Max();
            int delta = width / binsNum;
            for (int i = 0; i < binsNum; i++)
            {
                int binHeight = height * freq[i] / maxFreq;
                g.DrawRectangle(p3, i * delta, -binHeight + height, 7, binHeight);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Histogram
            // 
            this.ClientSize = new System.Drawing.Size(781, 460);
            this.Name = "Histogram";
            this.ResumeLayout(false);
        }

        /*
        private Vector aNormRV;
        private int binsNum;
        private void button2_Click(object sender, EventArgs e)
        {
            Random aRV = new Random(1234);

            aNormRV = new DFinMath.Vector(1000);

            for (int i = 0; i < 1000; i++)
            {
                aNormRV[i] = DStat.N_Inv(aRV.NextDouble());
            }

            double max = aNormRV.Max();
            double min = aNormRV.Min();

            binsNum = int.Parse(textBox1.Text);
            textBox2.Text = max.ToString("F6");
            textBox3.Text = min.ToString("F6");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Histogram aNormHist = new Histogram(aNormRV, binsNum);
            aNormHist.Show();
        }        
         */

    }
}
