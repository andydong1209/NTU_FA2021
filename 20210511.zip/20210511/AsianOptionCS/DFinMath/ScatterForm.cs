﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using DFinMath;

namespace DFinMath
{
    public partial class ScatterForm : Form
    {
        public ScatterForm()
        {
            InitializeComponent();

            this.Name = "ScatterPlot";
            this.Text = "ScatterPlot";

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 600);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

            this.Paint += new PaintEventHandler(ScatterForm_Paint);
        }

        private List<Vector> aRVData;
        private int NPath;
        private int MStep;

        public ScatterForm(List<Vector> RVData) : this()
        {
            aRVData = new List<Vector>();
            aRVData = RVData;
            NPath = aRVData.Count;
            MStep = aRVData[0].Count - 1;

            this.Text = "A RV Scatter Plot";
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void ScatterForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();

            //int dx = 3;
            Pen p1 = new Pen(Color.Blue, 2);
            Pen p2 = new Pen(Color.Red, 2);
            Pen p3 = new Pen(Color.Green, 2);

            List<Pen> Pens = new List<Pen>();
            Pens.Add(p1);
            Pens.Add(p2);
            Pens.Add(p3);

            Pen p4 = new Pen(Color.Black, 2);

            int width = this.ClientSize.Width;
            int height = this.ClientSize.Height;
            int x0 = width / 2;
            int y0 = height;
            int xmax = x0;
            int ymax = y0;

            g.DrawRectangle(p1, 0, 0, width - 2, height - 2);
            g.DrawLine(p2, 0, 300, 800, 300);
            g.DrawLine(p2, 400, 0, 400, 600);

            Brush aBrush = Brushes.DarkGreen;

            for (int i = 0; i < MStep; i++)
            {
                int x = 400 + Convert.ToInt32(aRVData[0][i] * 400);
                int y = 300 - Convert.ToInt32(aRVData[1][i] * 300);

                g.FillRectangle(aBrush, x, y, 5, 5);
            }
        }
    }
}
