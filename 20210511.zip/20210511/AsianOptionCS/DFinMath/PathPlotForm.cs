﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;


namespace DFinMath
{
    public class PathPlotForm : Form
    {
        public PathPlotForm()
        {
            this.Name = "PathPlot";
            this.Text = "PathPlot";

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 600);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ResumeLayout(false);

            this.Paint += new PaintEventHandler(PathPlotForm_Paint);
        }

        private List<Vector> aRVPath;
        private int NPath;
        private int MStep;

        public PathPlotForm(List<Vector> RVPath) : this()
        {
            aRVPath = new List<Vector>();
            aRVPath = RVPath;
            NPath = aRVPath.Count;
            MStep = aRVPath[0].Count - 1;

            this.Text = "A RV Path Plot";
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }

        private void PathPlotForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = this.CreateGraphics();

            //int dx = 3;
            Pen p1 = new Pen(Color.Blue, 2);
            Pen p2 = new Pen(Color.Red, 2);
            Pen p3 = new Pen(Color.Green, 2);

            List<Pen> Pens = new List<Pen>();
            Pens.Add(p1);
            Pens.Add(p2);
            Pens.Add(p3);

            Pen p4 = new Pen(Color.Black, 2);

            int width = this.ClientSize.Width;
            int height = this.ClientSize.Height;
            int x0 = width / 2;
            int y0 = height;
            int xmax = x0;
            int ymax = y0;

            g.DrawRectangle(p4, 0, 0, width - 2, height - 2);
            g.DrawLine(p4, 0, 300, 1000, 300);

            //Console.WriteLine(width.ToString() + " : " + height.ToString());

            int dx = width / MStep;            
            Point pt1, pt2;
            for (int i = 0; i < NPath; i++)
            {
                int penNum = (i % 3);

                pt1 = new Point(0, 300);
                for (int j = 1; j <= MStep; j++)
                {
                    pt2 = new Point(j * dx, 300 - (Convert.ToInt32(2 * (aRVPath[i][j] - 100.0))));
                    g.DrawLine(Pens[i], pt1, pt2);
                    pt1 = pt2;
                }
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Histogram
            // 
            this.ClientSize = new System.Drawing.Size(780, 460);
            this.Name = "PathPlot";
            this.ResumeLayout(false);
        }

    }
}
